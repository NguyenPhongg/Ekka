@extends('admin.layout')
@section('title', '')
@section('menu-data')
<input type="hidden" name="" class="menu-data" value="category-group | category">
@endsection()


@section('css')

@endsection()


@section('body')

@endsection()


@section('sub_layout')

@endsection()


@section('js')

@endsection()