// View
const IndexView = {
    init(){

    }
};
// Controller
(() => {
    function init(){

    }
    


    init()



})();