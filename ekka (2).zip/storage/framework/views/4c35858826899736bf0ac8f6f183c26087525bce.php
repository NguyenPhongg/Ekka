
<?php $__env->startSection('title', 'Giỏ hàng'); ?>

<?php $__env->startSection('css'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?>

    <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row ec_breadcrumb_inner">
                        <div class="col-md-6 col-sm-12">
                            <h2 class="ec-breadcrumb-title">Quên mật khẩu</h2>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <ul class="ec-breadcrumb-list">
                                <li class="ec-breadcrumb-item"><a href="/">Trang chủ</a></li>
                                <li class="ec-breadcrumb-item active">Quên mật khẩu</li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="ec-page-content section-space-p">
        <div class="container">
            <div class="row">
                <div class="col-md-12 text-center">
                    <div class="section-title">
                        <h2 class="ec-bg-title">Quên mật khẩu</h2>
                        <h2 class="ec-title">Quên mật khẩu</h2>
                        <p class="sub-title mb-3">Nhận đường dẫn reset mật khẩu</p>
                    </div>
                </div>
                <div class="ec-login-wrapper">
                    <div class="ec-login-container">
                        <div class="ec-login-form">
                            <?php if( Session::has('error') ): ?>
                                <div class="alert alert-danger" role="alert">
                                    <?php echo e(Session::get('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if( Session::has('success') ): ?>
                                <div class="alert alert-success" role="alert">
                                    <?php echo e(Session::get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <form  action="<?php echo e(route('customer.forgot')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <span class="ec-login-wrap">
                                    <label>Email*</label>
                                    <input type="text" name="email" placeholder="Email" required />
                                </span>  
                                <span class="ec-login-wrap ec-login-btn">
                                    <button class="btn btn-primary" type="submit">Khôi phục</button> 
                                </span>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sub_layout'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backend-data\ekka\resources\views/customer/forgot.blade.php ENDPATH**/ ?>