
<?php $__env->startSection('title', 'Trang cá nhân'); ?>

<?php $__env->startSection('css'); ?> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('body'); ?> 
    <div class="sticky-header-next-sec  ec-breadcrumb section-space-mb">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <div class="row ec_breadcrumb_inner">
                        <div class="col-md-6 col-sm-12">
                            <h2 class="ec-breadcrumb-title">Trang cá nhân</h2>
                        </div>
                        <div class="col-md-6 col-sm-12">
                            <!-- ec-breadcrumb-list start -->
                            <ul class="ec-breadcrumb-list">
                                <li class="ec-breadcrumb-item"><a href="/">Trang chủ</a></li>
                                <li class="ec-breadcrumb-item active">Trang cá nhân</li>
                            </ul>
                            <!-- ec-breadcrumb-list end -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Ec breadcrumb end -->

    <!-- Ec cart page -->
    <section class="ec-page-content section-space-p">
        <div class="container">
            <?php if( Session::has('error') ): ?>
                <div class="alert alert-danger" role="alert">
                    <?php echo e(Session::get('error')); ?>

                </div>
            <?php endif; ?>
            <?php if( Session::has('success') ): ?>
                <div class="alert alert-success" role="alert">
                    <?php echo e(Session::get('success')); ?>

                </div>
            <?php endif; ?>
            <div class="I-profile">
                <div class="tab-control">
                    <a data-name="profile" class="tab-control-item"><i class="far fa-user m-r-10"></i>Thông tin</a>
                    <a data-name="order" class="tab-control-item"><i class="far fa-list-alt m-r-10"></i>Đơn mua</a>
                    <a data-name="password" class="tab-control-item"><i class="fas fa-key m-r-10"></i>Đổi mật khẩu</a>
                    <a href="#" onclick="event.preventDefault();document.getElementById('logout-form').submit();" ><i class="fas fa-sign-out-alt m-r-10"></i>Đăng xuất</a>
                    <form id="logout-form" action="<?php echo e(route('customer.logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </div>
                <div class="tab-body">

                </div>
            </div>
        </div>
    </section> 
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sub_layout'); ?> 
    <div class="I-modal modal-order" modal-block="Order">
        <div class="modal-wrapper">
            <div class="modal-dialog">
                <div class="dialog-content">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Mã</th>
                                <th>Tên sản phẩm</th>
                                <th>Đơn giá</th>
                                <th>Giảm giá</th>
                                <th>Số lượng</th>
                                <th>Thành tiền</th>
                                <th>Trạng thái</th>
                            </tr>
                        </thead>
                        <tbody class="data-full-list"> 
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script src="<?php echo e(asset('customer/assets/js/page/profile.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('customer.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Backend-data\ekka\resources\views/customer/profile.blade.php ENDPATH**/ ?>